﻿/*I, Divy J Chaudhary, 000883969certify that this material is my original work.  
 * No other person's work has been used without due acknowledgement.*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB3A
{
    /// <summary>
    /// Represents a song as a type of media that can be encrypted and decrypted.
    /// </summary>
    public class Song : Media, IEncryptable
    {
        /// <summary>
        /// Gets the album name of the song.
        /// </summary>
        public string Album { get; private set; }

        /// <summary>
        /// Gets the artist name of the song.
        /// </summary>
        public string Artist { get; private set; }

        /// <summary>
        /// Initializes a new instance of the Song class.
        /// </summary>
        /// <param name="title">The title of the song.</param>
        /// <param name="year">The year the song was released.</param>
        /// <param name="album">The name of the album the song belongs to.</param>
        /// <param name="artist">The name of the artist who performed the song.</param>
        /// <param name="summary">A summary or description of the song.</param>
        public Song(string title, int year, string album, string artist, string summary)
            : base(title, year)
        {
            Album = album;
            Artist = artist;
        }

        /// <summary>
        /// Encrypts the album name using ROT13 encryption.
        /// </summary>
        /// <returns>The encrypted album name.</returns>
        public string Encrypt()
        {
            // Implement ROT13 encryption for the album
            char[] albumChars = Album.ToCharArray();
            for (int i = 0; i < albumChars.Length; i++)
            {
                char c = albumChars[i];
                if (char.IsLetter(c))
                {
                    char offset = char.IsUpper(c) ? 'A' : 'a';
                    albumChars[i] = (char)(offset + (c - offset + 13) % 26);
                }
            }
            Album = new string(albumChars);
            return Album;
        }

        /// <summary>
        /// Decrypts the title by replacing '---' with a space.
        /// </summary>
        /// <returns>The decrypted title.</returns>
        public string Decrypt()
        {
            // Custom decryption logic for songs (using '---' approach)
            string decryptedTitle = Title.Replace("---", " "); // Decryption logic
            return decryptedTitle;
        }
    }
}