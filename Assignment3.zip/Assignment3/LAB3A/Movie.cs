﻿/*I, Divy J Chaudhary, 000883969certify that this material is my original work.  
 * No other person's work has been used without due acknowledgement.*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB3A
{
    /// <summary>
    /// Represents a Movie, a type of media, with title, director, and summary information.
    /// </summary>
    public class Movie : Media, IEncryptable
    {
        /// <summary>
        /// Gets the director of the movie.
        /// </summary>
        public string Director { get; private set; }

        /// <summary>
        /// Gets the summary of the movie.
        /// </summary>
        public string Summary { get; private set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Movie"/> class with the specified title, year, director, and summary.
        /// </summary>
        /// <param name="title">The title of the movie.</param>
        /// <param name="year">The year the movie was released.</param>
        /// <param name="director">The director of the movie.</param>
        /// <param name="summary">The summary of the movie.</param>
        public Movie(string title, int year, string director, string summary)
            : base(title, year)
        {
            Director = director;
            Summary = summary;
        }

        /// <summary>
        /// Encrypts the movie's summary using ROT13 encryption.
        /// </summary>
        /// <returns>The encrypted summary of the movie.</returns>
        public string Encrypt()
        {
            // Implement ROT13 encryption for the summary
            char[] summaryChars = Summary.ToCharArray();
            for (int i = 0; i < summaryChars.Length; i++)
            {
                char c = summaryChars[i];
                if (char.IsLetter(c))
                {
                    char offset = char.IsUpper(c) ? 'A' : 'a';
                    summaryChars[i] = (char)(offset + (c - offset + 13) % 26);
                }
            }
            Summary = new string(summaryChars);
            return Summary;
        }

        /// <summary>
        /// Decrypts the movie's summary using custom decryption logic.
        /// </summary>
        /// <returns>The decrypted summary of the movie.</returns>
        public string Decrypt()
        {
            // Custom decryption logic for movies (using '-----' approach)
            string decryptedSummary = Summary.Replace("-----", Environment.NewLine);
            return decryptedSummary;
        }
    }
}
