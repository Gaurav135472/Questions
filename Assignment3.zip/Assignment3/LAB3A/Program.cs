﻿/*I, Divy J Chaudhary, 000883969certify that this material is my original work.  
 * No other person's work has been used without due acknowledgement.*/

using LAB3A;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB3A
{
    /// <summary>
    /// The main program class for Divy's Collections.
    /// </summary>
    class Program
    {
        static Media[] mediaArray = new Media[100];
        static int mediaCount = 0;

        static void Main(string[] args)
        {
            ReadData("data.txt"); // Load data from a file into mediaArray
            bool exit = false; // Declare the exit variable

            while (!exit)
            {
                DisplayMenu(ref exit);

                if (!exit)
                {
                    Console.WriteLine("Press any key to continue...");
                    var key = Console.ReadKey().Key;

                    // Check if the key is Enter or Return
                    if (key == ConsoleKey.Enter)
                    {
                        // Directly process the task assigned to the selected menu option
                    }

                    Console.Clear(); // Clear the console before the next iteration
                }
            }
        }

        /// <summary>
        /// Displays the main menu for Divy's Collections and handles user input.
        /// </summary>
        /// <param name="exit">A reference to the exit flag to control the program's termination.</param>
        static void DisplayMenu(ref bool exit)
        {
            Console.WriteLine("Divy's Collections Menu:");
            Console.WriteLine("1. List All Books");
            Console.WriteLine("2. List All Movies");
            Console.WriteLine("3. List All Songs");
            Console.WriteLine("4. List All Media");
            Console.WriteLine("5. Search All Media by Title");
            Console.WriteLine("6. Exit Program");

            Console.Write("Enter your choice (1-6): ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    ListAllBooks();
                    break;
                case "2":
                    ListAllMovies();
                    break;
                case "3":
                    ListAllSongs();
                    break;
                case "4":
                    ListAllMedia();
                    break;
                case "5":
                    SearchMediaByTitle();
                    break;
                case "6":
                    exit = true; // Set the exit flag to exit the loop
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;
            }
        }

        /// <summary>
        /// Reads data from a file and populates the mediaArray.
        /// </summary>
        /// <param name="fileName">The name of the file to read data from.</param>
        static void ReadData(string fileName)
        {
            try
            {
                using (StreamReader reader = new StreamReader(fileName))
                {
                    string line;
                    StringBuilder summaryBuilder = new StringBuilder();
                    string type = null;
                    string title = null;
                    int year = 0;
                    string director = null;
                    string author = null;

                    while ((line = reader.ReadLine()) != null)
                    {
                        if (line.StartsWith("BOOK|") || line.StartsWith("MOVIE|") || line.StartsWith("SONG|"))
                        {
                            if (summaryBuilder.Length > 0)
                            {
                                string summary = summaryBuilder.ToString();
                                if (type == "BOOK")
                                {
                                    author = line;
                                    // Decrypt the summary using ROT13 for books
                                    summary = CustomRot13.Decode(summary);
                                    mediaArray[mediaCount] = new Book(title, year, author, summary);
                                }
                                else if (type == "MOVIE")
                                {
                                    director = line;
                                    // Decrypt the summary using ROT13 for movies
                                    summary = CustomRot13.Decode(summary);
                                    mediaArray[mediaCount] = new Movie(title, year, director, summary);
                                }
                                else if (type == "SONG")
                                {
                                    string[] songParts = line.Split('|').Select(p => p.Trim()).ToArray();
                                    string album = songParts[0];
                                    string artist = songParts[1];
                                    // Decrypt the summary using ROT13 for songs
                                    summary = CustomRot13.Decode(summary);
                                    mediaArray[mediaCount] = new Song(title, year, album, artist, summary);
                                }
                                mediaCount++;
                                summaryBuilder.Clear();
                            }

                            var parts = line.Split('|').Select(p => p.Trim()).ToArray();
                            type = parts[0];
                            title = parts[1];
                            year = int.Parse(parts[2]);
                        }
                        else
                        {
                            // Append the summary line to the StringBuilder
                            summaryBuilder.AppendLine(line);
                        }
                    }

                    // Process the last media entry if any
                    if (type != null)
                    {
                        string summary = summaryBuilder.ToString();
                        if (type == "BOOK")
                        {
                            author = director; // Last line contains author for books
                            // Decrypt the summary using ROT13 for books
                            summary = CustomRot13.Decode(summary);
                            mediaArray[mediaCount] = new Book(title, year, author, summary);
                        }
                        else if (type == "MOVIE")
                        {
                            director = line; // Last line contains director for movies
                            // Decrypt the summary using ROT13 for movies
                            summary = CustomRot13.Decode(summary);
                            mediaArray[mediaCount] = new Movie(title, year, director, summary);
                        }
                        else if (type == "SONG")
                        {
                            string[] songParts = line.Split('|').Select(p => p.Trim()).ToArray();
                            string album = songParts[0];
                            string artist = songParts[1];
                            // Decrypt the summary using ROT13 for songs
                            summary = CustomRot13.Decode(summary);
                            mediaArray[mediaCount] = new Song(title, year, album, artist, summary);
                        }
                        mediaCount++;
                    }
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine("Error reading data: " + ex.Message);
            }
        }

        /// <summary>
        /// Searches for media by title and outputs the results.
        /// </summary>
        /// <param name="title">The title to search for in media.</param>
        static void SearchAndOutputMediaByTitle(string title)
        {
            var matchingMedia = mediaArray
                .Where(media => media != null && media.Title.Equals(title, StringComparison.OrdinalIgnoreCase))
                .ToList();

            if (matchingMedia.Count == 0)
            {
                Console.WriteLine("No media found with the title: " + title);
            }
            else
            {
                foreach (var media in matchingMedia)
                {
                    Console.WriteLine(media.ToString());
                    if (media is IEncryptable encryptable)
                    {
                        string decryptedSummary = encryptable.Decrypt();
                        Console.WriteLine("Decrypted Summary: " + decryptedSummary);
                    }
                }
            }
        }

        /// <summary>
        /// Lists all the books in the mediaArray.
        /// </summary>
        static void ListAllBooks()
        {
            Console.WriteLine("List of Books:");
            for (int i = 0; i < mediaCount; i++)
            {
                if (mediaArray[i] is Book book)
                {
                    Console.WriteLine($"Book Title: {book.Title} ({book.Year})");
                    Console.WriteLine($"Author: {book.Author}");
                    Console.WriteLine("-----");
                }
            }
        }

        /// <summary>
        /// Lists all the movies in the mediaArray.
        /// </summary>
        static void ListAllMovies()
        {
            Console.WriteLine("List of Movies:");
            for (int i = 0; i < mediaCount; i++)
            {
                if (mediaArray[i] is Movie movie)
                {
                    Console.WriteLine($"Movie Title: {movie.Title} ({movie.Year})");
                    Console.WriteLine($"Director: {movie.Director}");
                    Console.WriteLine("-----");
                }
            }
        }

        /// <summary>
        /// Lists all the songs in the mediaArray.
        /// </summary>
        static void ListAllSongs()
        {
            Console.WriteLine("List of Songs:");
            for (int i = 0; i < mediaCount; i++)
            {
                if (mediaArray[i] is Song song)
                {
                    Console.WriteLine($"Song Title: {song.Title} ({song.Year})");
                    Console.WriteLine($"Artist: {song.Artist}");
                    Console.WriteLine("------");
                }
            }
        }

        /// <summary>
        /// Lists all media items in the mediaArray.
        /// </summary>
        static void ListAllMedia()
        {
            Console.WriteLine("List of All Media:");
            for (int i = 0; i < mediaCount; i++)
            {
                Console.WriteLine($"{mediaArray[i].GetType().Name} Title: {mediaArray[i].Title} ({mediaArray[i].Year})");
                Console.WriteLine("------");
            }
        }

        /// <summary>
        /// Searches for media by title and displays the search results.
        /// </summary>
        static void SearchMediaByTitle()
        {
            Console.Write("Enter a search keyword: ");
            string keyword = Console.ReadLine();

            Console.WriteLine("Search Results:");
            for (int i = 0; i < mediaCount; i++)
            {
                if (mediaArray[i].Search(keyword))
                {
                    string summary = mediaArray[i] is IEncryptable encryptable ? encryptable.Decrypt() : "Summary not available";
                    Console.WriteLine($"{mediaArray[i].GetType().Name} Title: {mediaArray[i].Title}");
                    Console.WriteLine($"Summary: {summary}");
                    Console.WriteLine("-------");
                }
            }
        }
    }
}