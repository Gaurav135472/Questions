﻿/*I, Divy J Chaudhary, 000883969certify that this material is my original work.  
 * No other person's work has been used without due acknowledgement.*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB3A
{
    /// <summary>
    /// Represents a Book, a type of media, with title, author, and summary information.
    /// </summary>
    public class Book : Media, IEncryptable
    {
        /// <summary>
        /// Gets the author of the book.
        /// </summary>
        public string Author { get; private set; }

        /// <summary>
        /// Gets the summary of the book.
        /// </summary>
        public string Summary { get; private set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Book"/> class with the specified title, year, author, and summary.
        /// </summary>
        /// <param name="title">The title of the book.</param>
        /// <param name="year">The year the book was published.</param>
        /// <param name="author">The author of the book.</param>
        /// <param name="summary">The summary of the book.</param>
        public Book(string title, int year, string author, string summary)
            : base(title, year)
        {
            Author = author;
            Summary = summary;
        }

        /// <summary>
        /// Encrypts the book's summary using ROT13 encryption.
        /// </summary>
        /// <returns>The encrypted summary of the book.</returns>
        public string Encrypt()
        {
            // Implement ROT13 encryption for the summary
            char[] summaryChars = Summary.ToCharArray();
            for (int i = 0; i < summaryChars.Length; i++)
            {
                char c = summaryChars[i];
                if (char.IsLetter(c))
                {
                    char offset = char.IsUpper(c) ? 'A' : 'a';
                    summaryChars[i] = (char)(offset + (c - offset + 13) % 26);
                }
            }
            Summary = new string(summaryChars);
            return Summary;
        }

        /// <summary>
        /// Decrypts the book's summary using custom decryption logic.
        /// </summary>
        /// <returns>The decrypted summary of the book.</returns>
        public string Decrypt()
        {
            // Custom decryption logic for books (using '-----' approach)
            string decryptedSummary = Summary.Replace("-----", Environment.NewLine);
            return decryptedSummary;
        }
    }
}
