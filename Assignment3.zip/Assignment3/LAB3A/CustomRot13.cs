﻿/*I, Divy J Chaudhary, 000883969certify that this material is my original work.  
 * No other person's work has been used without due acknowledgement.*/

using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB3A
{
    /// <summary>
    /// A class that provides custom ROT13 encoding and decoding functionality.
    /// </summary>
    public static class CustomRot13
    {
        /// <summary>
        /// Encodes a given string using the ROT13 algorithm.
        /// </summary>
        /// <param name="input">The input string to encode.</param>
        /// <returns>The encoded string.</returns>
        public static string Encode(string input)
        {
            if (input == null)
            {
                return null; // or handle it as needed
            }

            string abc = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            char[] inputChars = input.ToCharArray();

            for (int i = 0; i < inputChars.Length; i++)
            {
                char c = inputChars[i];
                int index = abc.IndexOf(c);

                if (index != -1)
                {
                    int offset = char.IsLower(c) ? 'a' : 'A';
                    int encodedIndex = (index + 13) % 26;
                    inputChars[i] = (char)(offset + encodedIndex);
                }
            }

            return new string(inputChars);
        }

        /// <summary>
        /// Decodes a given string using the ROT13 algorithm (which is its own inverse).
        /// </summary>
        /// <param name="input">The input string to decode.</param>
        /// <returns>The decoded string.</returns>
        public static string Decode(string input)
        {
            if (input == null)
            {
                return null; // or handle it as needed
            }

            return Encode(input); // ROT13 is its own inverse
        }
    }
}