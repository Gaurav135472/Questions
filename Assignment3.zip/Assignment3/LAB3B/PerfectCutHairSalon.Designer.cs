﻿namespace LAB3B
{
    partial class PerfectCutHairSalon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.hairdresserGroupBox = new System.Windows.Forms.GroupBox();
            this.hairdresserComboBox = new System.Windows.Forms.ComboBox();
            this.serviceGroupBox = new System.Windows.Forms.GroupBox();
            this.servicesListBox = new System.Windows.Forms.ListBox();
            this.chargedItemsGroupBox = new System.Windows.Forms.GroupBox();
            this.chargedItemsListBox = new System.Windows.Forms.ListBox();
            this.priceGroupBox = new System.Windows.Forms.GroupBox();
            this.priceListBox = new System.Windows.Forms.ListBox();
            this.totalPriceLabel = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.addServiceButton = new System.Windows.Forms.Button();
            this.btnCalculateTotal = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.hairdresserGroupBox.SuspendLayout();
            this.serviceGroupBox.SuspendLayout();
            this.chargedItemsGroupBox.SuspendLayout();
            this.priceGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // hairdresserGroupBox
            // 
            this.hairdresserGroupBox.Controls.Add(this.hairdresserComboBox);
            this.hairdresserGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hairdresserGroupBox.Location = new System.Drawing.Point(20, 22);
            this.hairdresserGroupBox.Margin = new System.Windows.Forms.Padding(4);
            this.hairdresserGroupBox.Name = "hairdresserGroupBox";
            this.hairdresserGroupBox.Padding = new System.Windows.Forms.Padding(4);
            this.hairdresserGroupBox.Size = new System.Drawing.Size(231, 218);
            this.hairdresserGroupBox.TabIndex = 0;
            this.hairdresserGroupBox.TabStop = false;
            this.hairdresserGroupBox.Text = "Select a Hairdresser:";
            // 
            // hairdresserComboBox
            // 
            this.hairdresserComboBox.DisplayMember = "Key";
            this.hairdresserComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.hairdresserComboBox.FormattingEnabled = true;
            this.hairdresserComboBox.Location = new System.Drawing.Point(0, 21);
            this.hairdresserComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.hairdresserComboBox.Name = "hairdresserComboBox";
            this.hairdresserComboBox.Size = new System.Drawing.Size(215, 26);
            this.hairdresserComboBox.TabIndex = 0;
            this.hairdresserComboBox.ValueMember = "Value";
            // 
            // serviceGroupBox
            // 
            this.serviceGroupBox.Controls.Add(this.servicesListBox);
            this.serviceGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.serviceGroupBox.Location = new System.Drawing.Point(259, 22);
            this.serviceGroupBox.Margin = new System.Windows.Forms.Padding(4);
            this.serviceGroupBox.Name = "serviceGroupBox";
            this.serviceGroupBox.Padding = new System.Windows.Forms.Padding(4);
            this.serviceGroupBox.Size = new System.Drawing.Size(256, 218);
            this.serviceGroupBox.TabIndex = 1;
            this.serviceGroupBox.TabStop = false;
            this.serviceGroupBox.Text = "Select a Serivce:";
            // 
            // servicesListBox
            // 
            this.servicesListBox.FormattingEnabled = true;
            this.servicesListBox.ItemHeight = 18;
            this.servicesListBox.Location = new System.Drawing.Point(12, 21);
            this.servicesListBox.Name = "servicesListBox";
            this.servicesListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.servicesListBox.Size = new System.Drawing.Size(244, 184);
            this.servicesListBox.TabIndex = 0;
            this.servicesListBox.SelectedIndexChanged += new System.EventHandler(this.servicesListBox_SelectedIndexChanged_1);
            // 
            // chargedItemsGroupBox
            // 
            this.chargedItemsGroupBox.Controls.Add(this.chargedItemsListBox);
            this.chargedItemsGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chargedItemsGroupBox.Location = new System.Drawing.Point(527, 22);
            this.chargedItemsGroupBox.Name = "chargedItemsGroupBox";
            this.chargedItemsGroupBox.Size = new System.Drawing.Size(242, 218);
            this.chargedItemsGroupBox.TabIndex = 2;
            this.chargedItemsGroupBox.TabStop = false;
            this.chargedItemsGroupBox.Text = "Charged Items:";
            // 
            // chargedItemsListBox
            // 
            this.chargedItemsListBox.Enabled = false;
            this.chargedItemsListBox.FormattingEnabled = true;
            this.chargedItemsListBox.ItemHeight = 16;
            this.chargedItemsListBox.Location = new System.Drawing.Point(6, 21);
            this.chargedItemsListBox.Name = "chargedItemsListBox";
            this.chargedItemsListBox.Size = new System.Drawing.Size(216, 180);
            this.chargedItemsListBox.TabIndex = 0;
            // 
            // priceGroupBox
            // 
            this.priceGroupBox.Controls.Add(this.priceListBox);
            this.priceGroupBox.Location = new System.Drawing.Point(794, 22);
            this.priceGroupBox.Name = "priceGroupBox";
            this.priceGroupBox.Size = new System.Drawing.Size(110, 217);
            this.priceGroupBox.TabIndex = 3;
            this.priceGroupBox.TabStop = false;
            this.priceGroupBox.Text = "Price:";
            // 
            // priceListBox
            // 
            this.priceListBox.Enabled = false;
            this.priceListBox.FormattingEnabled = true;
            this.priceListBox.ItemHeight = 20;
            this.priceListBox.Location = new System.Drawing.Point(5, 21);
            this.priceListBox.Name = "priceListBox";
            this.priceListBox.Size = new System.Drawing.Size(99, 184);
            this.priceListBox.TabIndex = 0;
            // 
            // totalPriceLabel
            // 
            this.totalPriceLabel.AutoSize = true;
            this.totalPriceLabel.Location = new System.Drawing.Point(672, 252);
            this.totalPriceLabel.Name = "totalPriceLabel";
            this.totalPriceLabel.Size = new System.Drawing.Size(95, 20);
            this.totalPriceLabel.TabIndex = 4;
            this.totalPriceLabel.Text = "Total Price:";
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(762, 245);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(119, 27);
            this.textBox1.TabIndex = 5;
            // 
            // addServiceButton
            // 
            this.addServiceButton.Enabled = false;
            this.addServiceButton.Location = new System.Drawing.Point(132, 292);
            this.addServiceButton.Name = "addServiceButton";
            this.addServiceButton.Size = new System.Drawing.Size(160, 29);
            this.addServiceButton.TabIndex = 6;
            this.addServiceButton.Text = "Add Service";
            this.addServiceButton.UseVisualStyleBackColor = true;
            // 
            // btnCalculateTotal
            // 
            this.btnCalculateTotal.Enabled = false;
            this.btnCalculateTotal.Location = new System.Drawing.Point(312, 291);
            this.btnCalculateTotal.Name = "btnCalculateTotal";
            this.btnCalculateTotal.Size = new System.Drawing.Size(167, 27);
            this.btnCalculateTotal.TabIndex = 7;
            this.btnCalculateTotal.Text = "Calculate Total Price";
            this.btnCalculateTotal.UseVisualStyleBackColor = true;
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(502, 292);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(161, 27);
            this.btnReset.TabIndex = 8;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(695, 293);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(116, 25);
            this.btnExit.TabIndex = 9;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            // 
            // PerfectCutHairSalon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(932, 350);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnCalculateTotal);
            this.Controls.Add(this.addServiceButton);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.totalPriceLabel);
            this.Controls.Add(this.priceGroupBox);
            this.Controls.Add(this.chargedItemsGroupBox);
            this.Controls.Add(this.serviceGroupBox);
            this.Controls.Add(this.hairdresserGroupBox);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "PerfectCutHairSalon";
            this.Text = "Form1";
            this.hairdresserGroupBox.ResumeLayout(false);
            this.serviceGroupBox.ResumeLayout(false);
            this.chargedItemsGroupBox.ResumeLayout(false);
            this.priceGroupBox.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox hairdresserGroupBox;
        private System.Windows.Forms.ComboBox hairdresserComboBox;
        private System.Windows.Forms.GroupBox serviceGroupBox;
        private System.Windows.Forms.ListBox servicesListBox;
        private System.Windows.Forms.GroupBox chargedItemsGroupBox;
        private System.Windows.Forms.ListBox chargedItemsListBox;
        private System.Windows.Forms.GroupBox priceGroupBox;
        private System.Windows.Forms.ListBox priceListBox;
        private System.Windows.Forms.Label totalPriceLabel;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button addServiceButton;
        private System.Windows.Forms.Button btnCalculateTotal;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
    }
}

