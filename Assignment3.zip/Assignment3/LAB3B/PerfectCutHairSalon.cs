﻿/*I, Divy J Chaudhary, 000883969certify that this material is my original work.  
 * No other person's work has been used without due acknowledgement.*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LAB3B
{
    /// <summary>
    /// Represents the main form for the Perfect Cut Hair Salon application.
    /// </summary>
    public partial class PerfectCutHairSalon : Form
    {
        private decimal totalCost = 0;
        private bool hairdresserSelected = false;

        /// <summary>
        /// Initializes a new instance of the <see cref="PerfectCutHairSalon"/> class.
        /// </summary>
        public PerfectCutHairSalon()
        {
            InitializeComponent();

            // Populate the Hairdresser ComboBox
            hairdresserComboBox.Items.AddRange(new string[]
            {
                "Jane Samley",
                "Pat Johnson",
                "Ron Chambers",
                "Sue Pallon",
                "Laura Renkins"
            });

            // Populate the Services ListBox
            servicesListBox.Items.AddRange(new string[]
            {
                "Cut",
                "Wash, blow-dry, and style",
                "Colour",
                "Highlights",
                "Extensions",
                "Up-do"
            });

            // Disable the Add Service and Calculate Total Price Buttons initially
            addServiceButton.Enabled = false;
            btnCalculateTotal.Enabled = false;

            // Connect event handlers
            addServiceButton.Click += AddServiceButton_Click;
            btnCalculateTotal.Click += CalculateTotalButton_Click;
            btnReset.Click += ResetButton_Click;
            btnExit.Click += ExitButton_Click;
            hairdresserComboBox.SelectedIndexChanged += HairdresserComboBox_SelectedIndexChanged;
            servicesListBox.SelectedIndexChanged += ServicesListBox_SelectedIndexChanged;
        }

        private void HairdresserComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Check if a hairdresser is selected
            if (hairdresserComboBox.SelectedIndex >= 0)
            {
                if (!hairdresserSelected)
                {
                    string selectedHairdresser = hairdresserComboBox.SelectedItem.ToString();
                    chargedItemsListBox.Items.Add($"Hairdresser: {selectedHairdresser}");
                    decimal hairdresserPrice = GetHairdresserRate(hairdresserComboBox.SelectedIndex);
                    priceListBox.Items.Add("$" + hairdresserPrice.ToString("0.00").PadLeft(9)); // Left-align the price
                    totalCost += hairdresserPrice;
                    hairdresserSelected = true;
                }
            }

            // Enable the "Add Service" button if a hairdresser and at least one service is selected
            addServiceButton.Enabled = hairdresserSelected && servicesListBox.SelectedItems.Count > 0;
        }

        private void ServicesListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Enable the "Add Service" button if a hairdresser and at least one service is selected
            addServiceButton.Enabled = hairdresserSelected && servicesListBox.SelectedItems.Count > 0;
        }

        private void AddServiceButton_Click(object sender, EventArgs e)
        {
            // Check if at least one service is selected
            if (servicesListBox.SelectedItems.Count > 0)
            {
                // Display selected services in the chargedItemsListBox
                foreach (var service in servicesListBox.SelectedItems)
                {
                    string serviceName = service.ToString();
                    chargedItemsListBox.Items.Add($"Service: {serviceName}");
                    decimal serviceCost = CalculateServiceCost(serviceName);
                    priceListBox.Items.Add("$" + serviceCost.ToString("0.00").PadLeft(9)); // Left-align the price
                    totalCost += serviceCost;
                }
            }

            // Enable the "Calculate Total Price" button
            btnCalculateTotal.Enabled = true;

            // Clear the previous selection in the Services ListBox
            servicesListBox.ClearSelected();
        }

        private void CalculateTotalButton_Click(object sender, EventArgs e)
        {
            // Calculate the total cost
            totalCost = 0;

            if (hairdresserSelected)
            {
                totalCost += GetHairdresserRate(hairdresserComboBox.SelectedIndex);
            }

            foreach (var price in priceListBox.Items)
            {
                string priceString = price.ToString().Substring(1); // Remove '$' sign
                totalCost += decimal.Parse(priceString);
            }

            // Display the total cost in the adjacent TextBox with "$" sign on the left
            textBox1.Text = "$" + totalCost.ToString("0.00").PadLeft(10); // Left-align the total cost with "$" on the left
        }

        // Helper method to calculate the cost of a service based on its name
        private decimal CalculateServiceCost(string serviceName)
        {
            switch (serviceName)
            {
                case "Cut":
                    return 30;
                case "Wash, blow-dry, and style":
                    return 20;
                case "Colour":
                    return 40;
                case "Highlights":
                    return 50;
                case "Extensions":
                    return 200;
                case "Up-do":
                    return 60;
                default:
                    return 0;
            }
        }

        private decimal GetHairdresserRate(int selectedIndex)
        {
            decimal[] rates = { 30, 45, 40, 50, 55 };
            return rates[selectedIndex];
        }

        private void ResetButton_Click(object sender, EventArgs e)
        {
            // Clear the ComboBox, ListBoxes, and Total Price Label
            hairdresserComboBox.SelectedIndex = -1;
            servicesListBox.ClearSelected();
            chargedItemsListBox.Items.Clear();
            priceListBox.Items.Clear();
            totalCost = 0;
            totalPriceLabel.Text = "Total Price: ";

            // Reset variables and disable the Add Service and Calculate Total Price Buttons
            hairdresserSelected = false;
            addServiceButton.Enabled = false;
            btnCalculateTotal.Enabled = false;

            // Clear the total cost in the adjacent TextBox
            textBox1.Text = "";

            // Set focus to the Hairdresser ComboBox
            hairdresserComboBox.Focus();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void servicesListBox_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }
    }
}