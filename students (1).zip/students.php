<?php

try 
{
    $dbh = new PDO(
        "mysql:host=localhost;dbname=tooltime",
        "root",
        ""
    );
} catch (Exception $e) 
{
    die("ERROR: Couldn't connect. {$e->getMessage()}");
}


$act = filter_input(INPUT_GET, "act", FILTER_SANITIZE_SPECIAL_CHARS);
$id = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);

if ($act == "delete")
{
  $dbh->query("DELETE FROM students WHERE id=" . $id);

  $command = "SELECT * FROM students";
  $stmt = $dbh->prepare($command);
  $success = $stmt->execute([]);
}
else if ($act == "add") {
  $first_name = filter_input(INPUT_POST, "first_name", FILTER_SANITIZE_SPECIAL_CHARS);
  $last_name = filter_input(INPUT_POST, "last_name", FILTER_SANITIZE_SPECIAL_CHARS);
  $gpa = $_POST["gpa"];
  
  $insert_command = "INSERT INTO `students` (`id`, `first_name`, `last_name`, `gpa`)" . 
                    "VALUES (NULL, ?, ?, ?);";
  $insert_stmt = $dbh->prepare($insert_command);
  $insert_success = $insert_stmt->execute([$first_name, $last_name, $gpa]);
  if (!$insert_success) 
  {
    die("ERROR: Could not insert student.");
  }
  
  $command = "SELECT * FROM students";
  $stmt = $dbh->prepare($command);
  $success = $stmt->execute([]);
}
else if ($act == "edit")
{
  $selectCommand = "SELECT * FROM students WHERE id=?";
  $selectStmt = $dbh->prepare($selectCommand);
  $selectSuccess = $selectStmt->execute([$id]);
  if (!$selectSuccess) die("ERROR: Could not select student.");
  $editStudent = $selectStmt->fetch();

  $command = "SELECT * FROM students";
  $stmt = $dbh->prepare($command);
  $success = $stmt->execute([]);
}
else if ($act == "commit_edit")
{
  $first_name = filter_input(INPUT_POST, "first_name", FILTER_SANITIZE_SPECIAL_CHARS);
  $last_name = filter_input(INPUT_POST, "last_name", FILTER_SANITIZE_SPECIAL_CHARS);
  $gpa = $_POST["gpa"];  

  $update_command = "UPDATE `students` SET `first_name` = ?, `last_name` = ?," . 
                    "`gpa` = ? WHERE `students`.`id` = ?;";
  $update_stmt = $dbh->prepare($update_command);
  $update_success = $update_stmt->execute([ $first_name, $last_name, $gpa, $id ]);
  if (!$update_success) die("ERROR: Could not update student.");

  $command = "SELECT * FROM students";
  $stmt = $dbh->prepare($command);
  $success = $stmt->execute([]);
}
else 
{
  $command = "SELECT * FROM students";
  $stmt = $dbh->prepare($command);
  $success = $stmt->execute([]);   
}

$students = [];

if ($success)
{
  while ($row = $stmt->fetch())
  {
    $students[] = $row;
  }
}
else 
{
  die("ERROR: Could not fetch students from database.");
}
?>
<html>
  <head>
    <title>Student Management System</title>
  </head>
  <style>

    table, tr, td, th
    {
        border: 1px solid black;
    }

    td, th {
        padding: 10px;
    }

    table 
    {
        border-collapse: collapse;
    }

  </style>
  <body>

  <h1>Student Management System</h1>

  <h2>Students</h2>

  <table id="students">
    <tr><th>ID</th><th>First Name</th><th>Last Name</th><th>GPA</th>
        <th>Delete</th><th>Edit</th></tr>
    
    <?php for ($i = 0; $i < count($students); $i++)
          {
            echo "<tr><td>{$students[$i]['id']}</td>" . 
                 "<td>{$students[$i]['first_name']}</td>" . 
                 "<td>{$students[$i]['last_name']}</td>" . 
                 "<td>{$students[$i]['gpa']}</td>" . 
                 "<td><a href='students.php?act=delete&id=" . $students[$i]['id'] . 
                 "'>Delete</a></td>" . 
                 "<td><a href='students.php?act=edit&id=" . $students[$i]['id'] . 
                 "'>Edit</a></td></tr>" ;
          }
    ?>
  </table>

  <br />

  <?php 
  if ($act == "edit") 
  { 
  ?>
    <h2>Edit Student</h2>
    <div>
      <form action="students.php?act=commit_edit&id=<?php echo $editStudent['id'] ?>" 
            method="POST">
        <label for="first_name">First Name</label>
        <input type="text" name="first_name" 
               value="<?php echo $editStudent['first_name'] ?>" />
        <label for="last_name">Last Name</label>
        <input type="text" name="last_name" 
               value="<?php echo $editStudent['last_name'] ?>" />
        <label for="gpa">GPA</label>
        <input type="text" name="gpa" 
               value="<?php echo $editStudent['GPA'] ?>" />    
        <input type="submit" />
      </form>
    </div> 
  <?php 
  }
  else {
  ?>
    <h2>Add Student</h2>
    <div>
      <form action="students.php?act=add" method="POST">
        <label for="first_name">First Name</label>
        <input type="text" name="first_name" />
        <label for="last_name">Last Name</label>
        <input type="text" name="last_name" />
        <label for="gpa">GPA</label>
        <input type="text" name="gpa" />    
        <input type="submit" />
      </form>
    </div> 

  <?php } ?>
 
  <br />

  </body>
</html>