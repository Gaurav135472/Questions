import java.util.LinkedList;

/**
 * A sorted linked list that maintains elements in sorted order upon insertion.
 *
 * @param <T> the type of elements in this list
 */
public class SortedLinkedList<T extends Comparable<T>> {
    private LinkedList<T> list;

    /**
     * Constructs an empty sorted linked list.
     */
    public SortedLinkedList() {
        list = new LinkedList<>();
    }

    /**
     * Adds an element to the list in sorted order.
     *
     * @param element the element to add
     */
    public void add(T element) {
        int index = 0;
        for (T item : list) {
            if (element.compareTo(item) < 0) {
                break;
            }
            index++;
        }
        list.add(index, element);
    }

    /**
     * Retrieves the element at the specified position in this list.
     *
     * @param index index of the element to return
     * @return the element at the specified position in this list
     */
    public T get(int index) {
        return list.get(index);
    }

    /**
     * Converts the linked list to an array of elements.
     *
     * @param a the array to populate
     * @return an array containing all elements in the list in proper order
     */
    public T[] toArray(T[] a) {
        return list.toArray(a);
    }

    /**
     * Removes the specified element from this list if it is present.
     *
     * @param element element to be removed from this list, if present
     */
    public void remove(T element) {
        list.remove(element);
    }

    /**
     * Returns a string representation of this list.
     *
     * @return a string representation of the list
     */
    @Override
    public String toString() {
        return list.toString();
    }
}
