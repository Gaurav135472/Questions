import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
/**
 * I Gaurav Patel (000898120), this is my original work and has not been copied or adapted from any soruces
 */
/**
 * Main class for Assignment 4. This program compares the performance of different
 * data structures while maintaining sorted order upon insertion. It tests
 * ArrayList, SortedArray, SortedLinkedList, and a primitive array using insertion sort.
 * The program also validates the correctness of the sorting by calculating checksums.
 */
public class A4Main {

    /**
     * Entry point of the program. Executes Part A and Part B of the assignment
     * as specified in the problem statement.
     *
     * @param args command-line arguments (unused).
     */
    public static void main(String[] args) {
        runPartA();
        runPartB();
    }

    /**
     * Validates if an array of strings is sorted and computes a checksum for verification.
     * The checksum is calculated based on the hash codes of each string, weighted by
     * their position in the array. If the array is not sorted, the method returns -1.
     *
     * @param array the array of strings to validate.
     * @return a positive checksum value if the array is sorted, or -1 if it is not sorted.
     */
    public static int ckSumSorted(String[] array) {
        if (array.length == 0) {
            return 1;
        }
        int sum = 0;
        int i = 0;
        String prev = array[0];
        for (String str : array) {
            if (str == null || str.compareTo(prev) < 0) {
                return -1;
            }
            i++;
            sum += str.hashCode() * i;
            prev = str;
        }
        return Math.abs(sum % 1000000);
    }

    /**
     * Executes Part A of the assignment. This method:
     * - Tests the SortedLinkedList and SortedArray classes using a set of sample names.
     * - Verifies that the lists maintain sorted order upon insertion.
     * - Validates the sorting using checksums.
     * - Demonstrates functionality with a second LinkedList of integer data type.
     */
    public static void runPartA() {
        System.out.println("\n\n--- Part A ---\n");

        SortedLinkedList<String> linkedList = new SortedLinkedList<>();
        SortedArray<String> sortedArray = new SortedArray<>();

        String[] names = {"Bob", "Carol", "Aaron", "Alex", "Zaphod"};
        System.out.println("Initial Array: " + Arrays.toString(names));

        for (String name : names) {
            linkedList.add(name);
            sortedArray.add(name);
        }

        String[] sl = linkedList.toArray(new String[0]);
        System.out.println("LinkedList: " + Arrays.toString(sl));
        System.out.printf("LinkedList Checksum: %,d\n", ckSumSorted(sl));

        String[] sa = sortedArray.toArray(new String[0]);
        System.out.println("SortedArray: " + Arrays.toString(sa));
        System.out.printf("SortedArray Checksum: %,d\n", ckSumSorted(sa));

        System.out.println("\nRemoving elements from LinkedList...");
        for (String name : names) {
            linkedList.remove(name);
        }
        System.out.println("LinkedList after removals: " + linkedList);

        System.out.println("\nTesting with Integer data type...");
        SortedLinkedList<Integer> intList = new SortedLinkedList<>();
        intList.add(5);
        intList.add(1);
        intList.add(3);
        System.out.println("Integer LinkedList: " + intList);
        intList.remove(3);
        System.out.println("Integer LinkedList after removal: " + intList);
    }

    /**
     * Executes Part B of the assignment. This method:
     * - Reads data from the file bnames-2.txt into an ArrayList.
     * - Measures the time taken for operations on ArrayList, SortedLinkedList, SortedArray, and a primitive array.
     * - Validates the sorting of each data structure using checksums.
     * - Outputs the timing results for performance comparison.
     */
    public static void runPartB() {
        System.out.println("\n\n--- Part B ---\n");

        ArrayList<String> bnames = new ArrayList<>();
        long startTime;
        long endTime;

        try (Scanner scanner = new Scanner(new File("src/bnames-2.txt"))) {
            while (scanner.hasNextLine()) {
                bnames.add(scanner.nextLine().trim());
            }
        } catch (FileNotFoundException e) {
            System.err.println("File not found.");
            return;
        }
        System.out.println("Data read from file. Total items: " + bnames.size());

        String[] sa = new String[bnames.size()];
        for (int i = 0; i < bnames.size(); i++) {
            sa[i] = bnames.get(i);
        }

        ArrayList<String> sortedAL = new ArrayList<>();
        startTime = System.currentTimeMillis();
        for (String name : bnames) {
            sortedAL.add(name);
            sortedAL.sort(String::compareTo);
        }
        endTime = System.currentTimeMillis();
        System.out.printf("ArrayList Checksum: %,d\n", ckSumSorted(sa));
        System.out.printf("ArrayList Sorting Time: %,d ms\n", (endTime - startTime));

        SortedLinkedList<String> linkedList = new SortedLinkedList<>();
        startTime = System.currentTimeMillis();
        for (String name : bnames) {
            linkedList.add(name);
        }
        endTime = System.currentTimeMillis();
        System.out.printf("SortedLinkedList Time: %,d ms\n", (endTime - startTime));

        SortedArray<String> sortedArray = new SortedArray<>();
        startTime = System.currentTimeMillis();
        for (String name : bnames) {
            sortedArray.add(name);
        }
        endTime = System.currentTimeMillis();
        System.out.printf("SortedArray Time: %,d ms\n", (endTime - startTime));

        String[] primitiveArray = new String[bnames.size()];
        startTime = System.currentTimeMillis();
        for (int i = 0; i < bnames.size(); i++) {
            primitiveArray[i] = bnames.get(i);
            iSort(primitiveArray, i + 1);
        }
        endTime = System.currentTimeMillis();
        System.out.printf("Primitive Array Time: %,d ms\n", (endTime - startTime));
    }

    /**
     * Sorts a portion of a string array using insertion sort. The method only
     * sorts the first n elements of the array.
     *
     * @param array the array to sort.
     * @param n the number of elements to sort within the array.
     */
    public static void iSort(String[] array, int n) {
        for (int i = 1; i < n; i++) {
            String key = array[i];
            int j = i - 1;
            while (j >= 0 && array[j].compareTo(key) > 0) {
                array[j + 1] = array[j];
                j--;
            }
            array[j + 1] = key;
        }
    }
}
