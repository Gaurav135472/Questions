import java.util.ArrayList;
import java.util.Collections;

/**
 * A sorted array that maintains elements in sorted order upon insertion.
 *
 * @param <T> the type of elements in this array
 */
public class SortedArray<T extends Comparable<T>> {
    private ArrayList<T> array;

    /**
     * Constructs an empty sorted array.
     */
    public SortedArray() {
        array = new ArrayList<>();
    }

    /**
     * Adds an element to the array in sorted order.
     *
     * @param element the element to add
     */
    public void add(T element) {
        array.add(element);
        Collections.sort(array);
    }

    /**
     * Retrieves the element at the specified position in this array.
     *
     * @param index index of the element to return
     * @return the element at the specified position in this array
     */
    public T get(int index) {
        return array.get(index);
    }

    /**
     * Converts the array list to an array of elements.
     *
     * @param a the array to populate
     * @return an array containing all elements in sorted order
     */
    public T[] toArray(T[] a) {
        return array.toArray(a);
    }

    /**
     * Returns a string representation of this array.
     *
     * @return a string representation of the array
     */
    @Override
    public String toString() {
        return array.toString();
    }
}
